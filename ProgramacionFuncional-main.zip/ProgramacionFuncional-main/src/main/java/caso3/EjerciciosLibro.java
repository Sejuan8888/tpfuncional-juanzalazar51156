package caso3;

import java.util.*;
import java.util.stream.Collectors;

public class EjerciciosLibro {

    public static void main(String[] args) {
        // Datos de prueba
        List<Libro> libros = Arrays.asList(
                new Libro("El amor en los tiempos del cólera","Gabriel García Márquez",368,22.50),
                new Libro("La ciudad y los perros","Mario Vargas Llosa",440,21.99),
                new Libro("Fahrenheit 451","Ray Bradbury",192,17.99),
                new Libro("Un mundo feliz","Aldous Huxley",288,19.90),
               new Libro("Orgullo y prejuicio","Jane Austen",432,20.50),
                new Libro("Matar un ruiseñor", "Harper Lee",324,18.75),
                new Libro("El gran Gatsby","F. Scott Fitzgerald",180,16.50),
                new Libro("Crimen y castigo","Fiódor Dostoyevski",608,25.00),
               new Libro("Moby Dick","Herman Melville",720,27.80),
               new Libro("El Aleph","Jorge Luis Borges",208,19.99)
        );

        System.out.println("=== CASO PRÁCTICO 3: LIBROS ===\n");

        // 1. Listar los títulos de los libros con más de 300 páginas, ordenados alfabéticamente
        System.out.println("1. Títulos de libros con más de 300 páginas (ordenados alfabéticamente):");
        List<String> titulosLargos = libros.stream()
                .filter(libro -> libro.getPaginas() > 300)
                .map(Libro::getTitulo)
                .sorted()
                .collect(Collectors.toList());
        titulosLargos.forEach(titulo -> System.out.println("  - " + titulo));

        // 2. Calcular el promedio de páginas de todos los libros
        System.out.println("\n2. Promedio de páginas de todos los libros:");
        double promedioPaginas = libros.stream()
                .mapToInt(Libro::getPaginas)
                .average()
                .orElse(0.0);
        System.out.printf("  %.2f páginas%n", promedioPaginas);

        // 3. Agrupar los libros por autor y contar cuántos libros tiene cada uno
        System.out.println("\n3. Cantidad de libros por autor:");
        Map<String, Long> librosPorAutor = libros.stream()
                .collect(Collectors.groupingBy(
                        Libro::getAutor,
                        Collectors.counting()
                ));
        librosPorAutor.forEach((autor, cantidad) ->
                System.out.printf("  %s: %d libro(s)%n", autor, cantidad)
        );

        // 4. Obtener el libro más caro de la lista
        System.out.println("\n4. Libro más caro:");
        Optional<Libro> libroMasCaro = libros.stream()
                .max(Comparator.comparingDouble(Libro::getPrecio));
        libroMasCaro.ifPresent(libro ->
                System.out.printf("  %s - $%.2f%n", libro.getTitulo(), libro.getPrecio())
        );

        System.out.println("\n=== CONCLUSIONES ===");
        System.out.println("✓ Operaciones filter, map, sorted y collect practicadas");
        System.out.println("✓ Promedios y máximos manejados con Streams");
        System.out.println("✓ Agrupación con groupingBy() y counting() entendida");
    }
}

