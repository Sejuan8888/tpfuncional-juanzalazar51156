package caso4;

import java.util.*;
import java.util.stream.Collectors;

public class EjerciciosEmpleado {

    public static void main(String[] args) {
        // Datos de prueba
        List<Empleado> empleados = Arrays.asList(
                new Empleado("Javier Gómez", "IT", 4200.00, 40),
                new Empleado("Elena Rodríguez", "Marketing", 3000.00, 32),
                new Empleado("David Moreno", "Ventas", 2400.00, 25),
                new Empleado("Sara Muñoz", "Recursos Humanos", 2900.00, 34),
                new Empleado("Pablo Vidal", "IT", 5000.00, 45),
                new Empleado("Claudia Navarro", "Finanzas", 3300.00, 29),
                new Empleado("Daniel Ruiz", "Ventas", 2000.00, 22),
                new Empleado("Marta Sanz", "Marketing", 3100.00, 31),
                new Empleado("Sergio Alonso", "Finanzas", 3600.00, 37),
                new Empleado("Laura Pascual", "IT", 3900.00, 30)
        );

        System.out.println("=== CASO PRÁCTICO 4: EMPLEADOS ===\n");

        // 1. Obtener la lista de empleados cuyo salario sea mayor a 2000, ordenados por salario descendente
        System.out.println("1. Empleados con salario mayor a 2000 (ordenados por salario descendente):");
        List<Empleado> empleadosBienPagados = empleados.stream()
                .filter(e -> e.getSalario() > 2000)
                .sorted(Comparator.comparingDouble(Empleado::getSalario).reversed())
                .collect(Collectors.toList());
        empleadosBienPagados.forEach(e ->
                System.out.printf("  - %s: $%.2f (%s)%n", e.getNombre(), e.getSalario(), e.getDepartamento())
        );

        // 2. Calcular el salario promedio general
        System.out.println("\n2. Salario promedio general:");
        double salarioPromedio = empleados.stream()
                .mapToDouble(Empleado::getSalario)
                .average()
                .orElse(0.0);
        System.out.printf("  $%.2f%n", salarioPromedio);

        // 3. Agrupar los empleados por departamento y calcular la suma de salarios de cada uno
        System.out.println("\n3. Suma de salarios por departamento:");
        Map<String, Double> salariosPorDepartamento = empleados.stream()
                .collect(Collectors.groupingBy(
                        Empleado::getDepartamento,
                        Collectors.summingDouble(Empleado::getSalario)
                ));
        salariosPorDepartamento.forEach((departamento, suma) ->
                System.out.printf("  %s: $%.2f%n", departamento, suma)
        );

        // 4. Obtener los nombres de los 2 empleados más jóvenes
        System.out.println("\n4. Los 2 empleados más jóvenes:");
        List<String> dosMasJovenes = empleados.stream()
                .sorted(Comparator.comparingInt(Empleado::getEdad))
                .limit(2)
                .map(Empleado::getNombre)
                .collect(Collectors.toList());
        dosMasJovenes.forEach(nombre -> System.out.println("  - " + nombre));

        System.out.println("\n=== CONCLUSIONES ===");
        System.out.println("✓ Operaciones de filtro, ordenamiento y límite aplicadas");
        System.out.println("✓ Promedios y sumatorias calculadas con collectors");
        System.out.println("✓ groupingBy con downstream collectors (summingDouble) practicado");
    }
}
